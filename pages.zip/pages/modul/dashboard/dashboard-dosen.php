<?php 
    include 'pages/layouts/header.php';
    include 'pages/authorization-login.php'; 
 ?>

<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body">
              <section id="number-tabs">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                           
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<?php include 'pages/layouts/footer.php'; ?>